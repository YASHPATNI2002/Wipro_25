package com.wipro.ems.entity;

public enum EmployeeType {
    CONTRACT,
    REGULAR
}
